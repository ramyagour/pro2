package WebDriverLoginDemo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class LoginWeb {
	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:/Users/RAMGOUR/Desktop/Module 3/chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		  driver.get("file:///C:/Users/RAMGOUR/Desktop/Module%203/login.html");
	
		  //invalid username
		  Thread.sleep(2000);
		  driver.findElement(By.name("userName")).sendKeys("");
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		  Thread.sleep(2000);
		  callusererror();
		  Thread.sleep(2000);
		  
		  
		  //invalid password
		  driver.findElement(By.name("userName")).clear();
		  Thread.sleep(2000);
		  driver.findElement(By.name("userName")).sendKeys("capgemini");
		  Thread.sleep(2000);
		  driver.findElement(By.name("userPwd")).sendKeys("");
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		  Thread.sleep(2000);
		  callpasserror();
		  Thread.sleep(2000);
		  
		  
		  //invalid details
		  driver.findElement(By.name("userName")).clear();
		  Thread.sleep(2000);
		  driver.findElement(By.name("userName")).sendKeys("ramya");
		  Thread.sleep(2000);
		  driver.findElement(By.name("userPwd")).clear();
		  driver.findElement(By.name("userPwd")).sendKeys("qwerty");
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		  Thread.sleep(2000);
		  callalert();
		  Thread.sleep(2000);
		  
		  //valid details
		  driver.findElement(By.name("userName")).clear();
		  Thread.sleep(2000);
		  driver.findElement(By.name("userName")).sendKeys("capgemini");
		  Thread.sleep(2000);
		  driver.findElement(By.name("userPwd")).clear();
		  driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		  Thread.sleep(2000);
		  driver.findElement(By.xpath(".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		  Thread.sleep(2000);
		  driver.navigate().to("file:///C:/Users/RAMGOUR/Desktop/Module%203/hotelbooking.html");
		  Thread.sleep(2000);
		  
		  
		  
	}
	public static void callalert() throws InterruptedException
	{
		
		String alertmsg=driver.switchTo().alert().getText();
		System.out.println(alertmsg);
		driver.switchTo().alert().accept();
		
	}

	
	public static void callusererror() throws InterruptedException
	{
		
		WebElement element = driver.findElement(By.xpath(".//*[@id='userErrMsg']"));
        System.out.println(element.getText());

        if(element.getText().equals("* Please enter userName.")){
            System.out.println("true");

        }else{
                System.out.println("false");
        }
		
	}
	
	
	public static void callpasserror() throws InterruptedException
	{
		
		 WebElement element = driver.findElement(By.xpath(".//*[@id='pwdErrMsg']"));
	        System.out.println(element.getText());

	        if(element.getText().equals("* Please enter password.")){
	            System.out.println("true");

	        }else{
	                System.out.println("false");
	        }
		
	}
}
