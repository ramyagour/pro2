package LoginPageDemo;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import LoginPageBean.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class StepDefLogin {
	private WebDriver driver;
	private LoginPage obj1;
	@Given("^user is on hotel booking login page$")
	public void user_is_on_hotel_booking_login_page() throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "C:/Users/RAMGOUR/Desktop/Module 3/chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		  obj1= new LoginPage(driver);
		   driver.get("file:///C:/Users/RAMGOUR/Desktop/Module%203/login.html");
	}

	@Then("^Check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("Hotel Booking Application"))
			System.out.println("****Welcome*****");
		else
			System.out.println("*******Title not matched*************");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^user enter valid credentials and clicks the button$")
	public void user_enter_valid_credentials_and_clicks_the_button() throws Throwable {
	    obj1.setPfuname("capgemini");
	    Thread.sleep(2000);
	    obj1.setPfpwd("capg1234");
	    Thread.sleep(2000);
	    driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	    obj1.setPfbutton();
	}

	@Then("^navigate to hotel booking page$")
	public void navigate_to_hotel_booking_page() throws Throwable {
		driver.navigate().to("file:///C:/Users/RAMGOUR/Desktop/Module%203/hotelbooking.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enter invalid username and clicks the button$")
	public void user_enter_invalid_username_and_clicks_the_button() throws Throwable {
		 obj1.setPfuname("");
		    Thread.sleep(2000);
		    driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		    
		    obj1.setPfbutton();
	}

	@Then("^alert message is displayed$")
	public void alert_message_is_displayed() throws Throwable {
		 String alertmsg=driver.switchTo().alert().getText();
		   Thread.sleep(2000);
		   driver.switchTo().alert().accept();
		   System.out.println("*******"+alertmsg);
		  driver.close();
	}

	@When("^user enter invalid password and clicks the button$")
	public void user_enter_invalid_password_and_clicks_the_button() throws Throwable {
		 obj1.setPfuname("capgemini");
		    Thread.sleep(2000);
		    obj1.setPfpwd("");
		    Thread.sleep(2000);
		    driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		   
		    obj1.setPfbutton();
	}

	@When("^user enter all invalid credentials and clicks the button$")
	public void user_enter_all_invalid_credentials_and_clicks_the_button() throws Throwable {
		  obj1.setPfuname("ramya");
		   Thread.sleep(2000);
		   obj1.setPfpwd("qwerty");
		   Thread.sleep(2000);
		   driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		   obj1.setPfbutton();
	}
	@Then("^alert message is displayed for username$")
	public void alert_message_is_displayed_for_username() throws Throwable {
		WebElement element = driver.findElement(By.xpath(".//*[@id='userErrMsg']"));
        System.out.println(element.getText());

        if(element.getText().equals("* Please enter userName.")){
            System.out.println("true");

        }else{
                System.out.println("false");
        }
	}

	@Then("^alert message is displayed for password$")
	public void alert_message_is_displayed_for_password() throws Throwable {
		 WebElement element = driver.findElement(By.xpath(".//*[@id='pwdErrMsg']"));
	        System.out.println(element.getText());

	        if(element.getText().equals("* Please enter password.")){
	            System.out.println("true");

	        }else{
	                System.out.println("false");
	        }
	}


}
