package LoginHotel;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import LoginHotelBean.PageHotel;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefLogin {
	private WebDriver driver;
	private PageHotel obj;
	
	@Given("^user has open the browser and is on login page$")
	public void user_has_open_the_browser_and_is_on_login_page() throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "C:/Users/RAMGOUR/Desktop/Module 3/chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		  obj= new PageHotel(driver);
		   driver.get("file:///C:/Users/RAMGOUR/Desktop/Module%203/login.html");
	}

	@Then("^check the title of page$")
	public void check_the_title_of_page() throws Throwable {
	   String title=driver.getTitle();
		if(title.contentEquals("Hotel Booking Application"))
			System.out.println("****Welcome*****");
		else
			System.out.println("*******Title not matched*************");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^enter invalid credentials$")
	public void enter_invalid_credentials() throws Throwable {
	   obj.setPfuname("ramya");
	   Thread.sleep(2000);
	   obj.setPfpwd("qwerty");
	   Thread.sleep(2000);
	   obj.setPfbtn();
	   Thread.sleep(2000);
	}

	@Then("^alert message is generated$")
	public void alert_message_is_generated() throws Throwable {
		 String alertmsg=driver.switchTo().alert().getText();
		   Thread.sleep(2000);
		   driver.switchTo().alert().accept();
		   System.out.println("*******"+alertmsg);
		  driver.close();
	}

	@When("^does not enter username$")
	public void does_not_enter_username() throws Throwable {
	    obj.setPfuname("");
	    Thread.sleep(2000);
	    driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	    obj.setPfbtn();
	    Thread.sleep(2000);
	}

	@Then("^alert message is generated for username$")
	public void alert_message_is_generated_for_username() throws Throwable {
		WebElement element = driver.findElement(By.xpath(".//*[@id='userErrMsg']"));
        System.out.println(element.getText());

        if(element.getText().equals("* Please enter userName.")){
            System.out.println("true");

        }else{
                System.out.println("false");
        }
        driver.close();
	}

	@When("^does not enter password$")
	public void does_not_enter_password() throws Throwable {
	  obj.setPfuname("capgemini");
	  Thread.sleep(2000);
	  obj.setPfpwd("");
	  Thread.sleep(2000);
	  obj.setPfbtn();
	  Thread.sleep(2000);
	}

	@Then("^alert message is generated for password$")
	public void alert_message_is_generated_for_password() throws Throwable {
		WebElement element = driver.findElement(By.xpath(".//*[@id='pwdErrMsg']"));
        System.out.println(element.getText());

        if(element.getText().equals("* Please enter password.")){
            System.out.println("true");

        }else{
                System.out.println("false");
        }
        driver.close();
	}

	@When("^enter valid credentials$")
	public void enter_valid_credentials() throws Throwable {
	  obj.setPfuname("capgemini");
	  Thread.sleep(2000);
	  		obj.setPfpwd("capg1234");
	  		Thread.sleep(2000);
	  		Thread.sleep(2000);
	  		obj.setPfbtn();
	  		Thread.sleep(2000);
	  
	}

	@Then("^navigate to the hotel booking page$")
	public void navigate_to_the_hotel_booking_page() throws Throwable {
		driver.navigate().to("file:///C:/Users/RAMGOUR/Desktop/Module%203/hotelbooking.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.close();
	}
}
