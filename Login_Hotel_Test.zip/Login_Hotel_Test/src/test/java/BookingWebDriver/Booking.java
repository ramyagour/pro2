package BookingWebDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Booking {
static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
	
		 System.setProperty("webdriver.chrome.driver", "C:/Users/RAMGOUR/Desktop/Module 3/chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.get("file:///C:/Users/RAMGOUR/Desktop/Module%203/hotelbooking.html");
		   
		   
		   driver.findElement(By.name("txtFN")).sendKeys("ramya");
		   Thread.sleep(2000);
		   driver.findElement(By.name("txtLN")).sendKeys("sharma");
		   Thread.sleep(2000);
		   driver.findElement(By.name("Email")).sendKeys("ramya@gmail.com");
		   Thread.sleep(2000);
		   driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("9627047924");
		   Thread.sleep(2000);
		   driver.findElement(By.name("city")).sendKeys("Pune");
		   Thread.sleep(2000);
		   driver.findElement(By.name("state")).sendKeys("Maharashtra");
		   Thread.sleep(2000);
		   driver.findElement(By.name("persons")).sendKeys("4");
		   Thread.sleep(2000);
		   driver.findElement(By.id("txtCardholderName")).sendKeys("ramya gour");
		   Thread.sleep(2000);
		   driver.findElement(By.id("txtDebit")).sendKeys("7654 9878 3421 8734");
		   Thread.sleep(2000);
		   driver.findElement(By.id("txtCvv")).sendKeys("654");
		   Thread.sleep(2000);
		   driver.findElement(By.id("txtMonth")).sendKeys("08");
		   Thread.sleep(2000);
		   driver.findElement(By.id("txtYear")).sendKeys("22");
		   Thread.sleep(2000);
		   driver.findElement(By.id("btnPayment")).click();
		   Thread.sleep(2000);
		   callalert();
		   Thread.sleep(2000);
		   driver.quit();
		   Thread.sleep(2000);
		   		  
		   
	}
	public static void callalert() throws InterruptedException
	{
		
		String alertmsg=driver.switchTo().alert().getText();
		System.out.println(alertmsg);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

		 driver.close();
	}
}
