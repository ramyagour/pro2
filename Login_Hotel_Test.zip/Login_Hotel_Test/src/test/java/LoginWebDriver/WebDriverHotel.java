package LoginWebDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriverHotel {
	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		 System.setProperty("webdriver.chrome.driver", "C:/Users/RAMGOUR/Desktop/Module 3/chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.get("file:///C:/Users/RAMGOUR/Desktop/Module%203/login.html");
		   
		   driver.findElement(By.name("userName")).sendKeys("capgemini");
		   Thread.sleep(2000);
		   driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		   Thread.sleep(2000);
		   driver.findElement(By.xpath(".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		   Thread.sleep(2000);
		 callalert();
		 Thread.sleep(2000);
		 driver.quit();
	}

	  public static void callalert() throws InterruptedException
		{
			
			String alertmsg=driver.switchTo().alert().getText();
			System.out.println(alertmsg);
			driver.switchTo().alert().accept();
			
		}
}
