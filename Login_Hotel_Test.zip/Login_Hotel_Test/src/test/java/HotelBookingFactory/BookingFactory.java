package HotelBookingFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class BookingFactory {
	WebDriver driver;

	//step 1:identify elements

	@FindBy(name="txtFN")
	@CacheLookup
	WebElement pffname;
	
	
	//using how class
	@FindBy(how=How.ID, using="btnPayment")
	@CacheLookup
	WebElement pfbutton;
	
	@FindBy(xpath=".//*[@id='txtLastName']")
	@CacheLookup
	WebElement pflname;
	
	@FindBy(how=How.NAME, using="Email")
	@CacheLookup
	WebElement pfemail;
	
	@FindBy(css="input[pattern='[789][0-9]{9}']")
	@CacheLookup
	WebElement pfphone;
	
	@FindBy(how=How.NAME, using="city")
	@CacheLookup
	WebElement pfcity;
	
	@FindBy(how=How.NAME, using="state")
	@CacheLookup
	WebElement pfstate;
	
	@FindBy(how=How.NAME, using="persons")
	@CacheLookup
	WebElement pfpersons;
	
	@FindBy(how=How.ID, using="txtCardholderName")
	@CacheLookup
	WebElement pfcardholder;
	
	
	@FindBy(how=How.ID, using="txtDebit")
	@CacheLookup
	WebElement pfdebit;
	
	@FindBy(how=How.ID, using="txtCvv")
	@CacheLookup
	WebElement pfCvv;
	
	@FindBy(how=How.ID, using="txtMonth")
	@CacheLookup
	WebElement pfmonth;
	
	@FindBy(how=How.ID, using="txtYear")
	@CacheLookup
	WebElement pfyear;

	
	//Getter and Setter methods
	
	

	public WebElement getPffname() {
		return pffname;
	}

	public void setPffname(String sfname) {
		pffname.sendKeys(sfname);
	}

	public WebElement getPfbutton() {
		return pfbutton;
	}

	public void setPfbutton() {
		pfbutton.click();
	}

	public WebElement getPflname() {
		return pflname;
	}

	public void setPflname(String slname) {
		pflname.sendKeys(slname);
	}

	public WebElement getPfemail() {
		return pfemail;
	}

	public void setPfemail(String semail) {
		pfemail.sendKeys(semail);
	}

	public WebElement getPfphone() {
		return pfphone;
	}

	public void setPfphone(String sphone) {
		pfphone.sendKeys(sphone);
	}

	public WebElement getPfcity() {
		return pfcity;
	}

	public void setPfcity(String scity) {
		Select drpCity=new Select(pfcity);
		drpCity.selectByVisibleText(scity);
		
	}

	public WebElement getPfstate() {
		return pfstate;
	}

	public void setPfstate(String sstate) {
		Select drpstate=new Select(pfstate);
		drpstate.selectByVisibleText(sstate);
	}

	

	public WebElement getPfpersons() {
		return pfpersons;
	}

	public void setPfpersons(String spersons) {
		Select drpperson=new Select(pfpersons);
		drpperson.selectByVisibleText(spersons);
	}

	public WebElement getPfcardholder() {
		return pfcardholder;
	}

	public void setPfcardholder(String scardholder) {
		pfcardholder.sendKeys(scardholder);
	}

	public WebElement getPfdebit() {
		return pfdebit;
	}

	public void setPfdebit(String sdebit) {
		pfdebit.sendKeys(sdebit);
	}

	public WebElement getPfCvv() {
		return pfCvv;
	}

	public void setPfCvv(String sCvv) {
		pfCvv.sendKeys(sCvv);
	}

	public WebElement getPfmonth() {
		return pfmonth;
	}

	public void setPfmonth(String smonth) {
		pfmonth.sendKeys(smonth);
	}

	public WebElement getPfyear() {
		return pfyear;
	}

	public void setPfyear(String syear) {
		pfyear.sendKeys(syear);
	}

	public BookingFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
}
