package HotelBooking;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import HotelBookingFactory.BookingFactory;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefBooking {
	private WebDriver driver;
	private BookingFactory obj;
	@Given("^user is on hotel booking page$")
	public void user_is_on_hotel_booking_page() throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "C:/Users/RAMGOUR/Desktop/Module 3/chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		   obj=new BookingFactory(driver);
		   driver.get("file:///C:/Users/RAMGOUR/Desktop/Module%203/hotelbooking.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("Hotel Booking"))
			System.out.println("****Welcome*****");
		else
			System.out.println("*******Title not matched*************");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^user enter valid details$")
	public void user_enter_valid_details() throws Throwable {
		  obj.setPffname("Ramya");
		   Thread.sleep(2000);
		   obj.setPflname("Sharma");
		   Thread.sleep(2000);
		   obj.setPfemail("ramyasharma@gmail.com");
		   Thread.sleep(2000);
		   obj.setPfphone("7895167416");
		   Thread.sleep(2000);
		   obj.setPfcity("Pune");
		   Thread.sleep(2000);
		   obj.setPfstate("Maharashtra");
		   Thread.sleep(2000);
		   obj.setPfpersons("4");
		   Thread.sleep(2000);
		   obj.setPfcardholder("ramya gour");
		   Thread.sleep(2000);
		   obj.setPfdebit("6545 8765 8765 9876");
		   Thread.sleep(2000);
		   obj.setPfCvv("456");
		   Thread.sleep(2000);
		   obj.setPfmonth("08");
		   Thread.sleep(2000);
		   obj.setPfyear("25");
		   Thread.sleep(2000);
		   driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		   obj.setPfbutton();
		  
	}

	@Then("^navigate to success page$")
	public void navigate_to_success_page() throws Throwable {
		driver.navigate().to("C://Users//RAMGOUR//Desktop//Module 3//Success.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user does not enter first name$")
	public void user_does_not_enter_first_name() throws Throwable {
		 obj.setPffname("");
		   Thread.sleep(2000);
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
		 obj.setPfbutton();
	}

	@Then("^alert box appears displaying the message$")
	public void alert_box_appears_displaying_the_message() throws Throwable {
		 String alertmsg=driver.switchTo().alert().getText();
		   Thread.sleep(2000);
		   driver.switchTo().alert().accept();
		   System.out.println("*******"+alertmsg);
		  driver.close();
	}

	@When("^user does not enter last name and clicks button$")
	public void user_does_not_enter_last_name_and_clicks_button() throws Throwable {
		obj.setPffname("ramya");
		 Thread.sleep(2000);
	  obj.setPflname("");
	  Thread.sleep(2000);
	  obj.setPfbutton();
	   Thread.sleep(2000);
	}

	@When("^user does not enter email and clicks the button$")
	public void user_does_not_enter_email_and_clicks_the_button() throws Throwable {
		obj.setPffname("ramya");
		 Thread.sleep(2000);
		obj.setPflname("sharma");
		 Thread.sleep(2000);
	 obj.setPfemail("");
	 Thread.sleep(2000);
	 obj.setPfbutton();
	   Thread.sleep(2000);
	}

	@When("^user enter incorrect mobileNo format and clicks buttons$")
	public void user_enter_incorrect_mobileNo_format_and_clicks_buttons(DataTable arg1) throws Throwable {
		obj.setPffname("ramya");
		 Thread.sleep(2000);
		 obj.setPflname("sharma");
		 Thread.sleep(2000);
		 obj.setPfemail("ramyasharma@gmail.com");
		 Thread.sleep(2000);
		 List<String> objList = arg1.asList(String.class);
			//obj.setPfmobile(objList);	Thread.sleep(1000);
			obj.setPfbutton();
			
			for(int i=0; i<objList.size(); i++) {
				if(Pattern.matches("^[789][0-9]{9}$", objList.get(i))) {
				System.out.println("***** Matched" + objList.get(i) + "*****");
				}
				else {
					System.out.println("***** NOT Matched" + objList.get(i) + "*****");
				}
			}
	}

	@When("^user does not select city and clicks the button$")
	public void user_does_not_select_city_and_clicks_the_button() throws Throwable {
		obj.setPffname("ramya");
		 Thread.sleep(2000);
		 obj.setPflname("sharma");
		 Thread.sleep(2000);
		 obj.setPfemail("ramyasharma@gmail.com");
		 Thread.sleep(2000);
		 obj.setPfphone("7895167416");
		 Thread.sleep(2000);
		 obj.setPfcity("Select City");
		 Thread.sleep(2000);
		 obj.setPfbutton();
		   Thread.sleep(2000);
	}

	@When("^user does not select state and clicks the button$")
	public void user_does_not_select_state_and_clicks_the_button() throws Throwable {
		obj.setPffname("ramya");
		 Thread.sleep(2000);
		 obj.setPflname("sharma");
		 Thread.sleep(2000);
		 obj.setPfemail("ramyasharma@gmail.com");
		 Thread.sleep(2000);
		 obj.setPfphone("7895167416");
		 Thread.sleep(2000);
		 obj.setPfcity("Pune");
		 Thread.sleep(2000);
		 obj.setPfstate("Select State");
		 Thread.sleep(2000);
		 obj.setPfbutton();
		   Thread.sleep(2000);
	}

	@When("^user enters (\\d+)$")
	public void user_enters(String arg1) throws Throwable {
		obj.setPffname("ramya");
		 Thread.sleep(2000);
		 obj.setPflname("sharma");
		 Thread.sleep(2000);
		 obj.setPfemail("ramyasharma@gmail.com");
		 Thread.sleep(2000);
		 obj.setPfphone("7895167416");
		 Thread.sleep(2000);
		 obj.setPfcity("Pune");
		 Thread.sleep(2000);
		 obj.setPfstate("Maharashtra");
		 Thread.sleep(2000);
		 obj.setPfpersons(arg1);
		 obj.setPfbutton();
		   Thread.sleep(2000);
	}

	@Then("^allocate rooms such that (\\d+) room for minimum (\\d+) guests$")
	public void allocate_rooms_such_that_room_for_minimum_guests(int arg1, int arg2) throws Throwable {
		if(arg2 <=3) {
	    	System.out.println("***** 1 room");
	    	assertEquals(1, arg1);
	    }
	    else if(arg2 <=6){
	    	System.out.println("***** 2 rooms");
	    	assertEquals(2, arg1); 	
	    }	 
	    else if(arg2 <=9){
	    	System.out.println("***** 3 rooms");
	    	assertEquals(3, arg1); 	
	    }
	}

	@When("^user does not enter card holder name and clicks the button$")
	public void user_does_not_enter_card_holder_name_and_clicks_the_button() throws Throwable {
		obj.setPffname("ramya");
		 Thread.sleep(2000);
		 obj.setPflname("sharma");
		 Thread.sleep(2000);
		 obj.setPfemail("ramyasharma@gmail.com");
		 Thread.sleep(2000);
		 obj.setPfphone("7895167416");
		 Thread.sleep(2000);
		 obj.setPfcity("Pune");
		 Thread.sleep(2000);
		 obj.setPfstate("Maharashtra");
		 Thread.sleep(2000);
		 obj.setPfpersons("4");
		 Thread.sleep(2000);
	   obj.setPfcardholder("");
	   Thread.sleep(2000);
	   obj.setPfbutton();
	   Thread.sleep(2000);
	}

	@When("^user does not enter debit card number and clicks the button$")
	public void user_does_not_enter_debit_card_number_and_clicks_the_button() throws Throwable {
		obj.setPffname("ramya");
		 Thread.sleep(2000);
		 obj.setPflname("sharma");
		 Thread.sleep(2000);
		 obj.setPfemail("ramyasharma@gmail.com");
		 Thread.sleep(2000);
		 obj.setPfphone("7895167416");
		 Thread.sleep(2000);
		 obj.setPfcity("Pune");
		 Thread.sleep(2000);
		 obj.setPfstate("Maharashtra");
		 Thread.sleep(2000);
		 obj.setPfpersons("4");
		 Thread.sleep(2000);
		 obj.setPfcardholder("ramya gour");
		 Thread.sleep(2000);
	  obj.setPfdebit("");
	  Thread.sleep(2000);
	  obj.setPfbutton();
	   Thread.sleep(2000);
	}

	@When("^user does not enter CVV and clicks the button$")
	public void user_does_not_enter_CVV_and_clicks_the_button() throws Throwable {
		obj.setPffname("ramya");
		 Thread.sleep(2000);
		 obj.setPflname("sharma");
		 Thread.sleep(2000);
		 obj.setPfemail("ramyasharma@gmail.com");
		 Thread.sleep(2000);
		 obj.setPfphone("7895167416");
		 Thread.sleep(2000);
		 obj.setPfcity("Pune");
		 Thread.sleep(2000);
		 obj.setPfstate("Maharashtra");
		 Thread.sleep(2000);
		 obj.setPfpersons("4");
		 Thread.sleep(2000);
		 obj.setPfcardholder("ramya gour");
		 Thread.sleep(2000);
	  obj.setPfdebit("6543 8765 9876 2345");
	  Thread.sleep(2000);
	  obj.setPfCvv("");
	  Thread.sleep(2000);
	  obj.setPfbutton();
	   Thread.sleep(2000);
	}

	@When("^user does not enter expiration month and clicks the button$")
	public void user_does_not_enter_expiration_month_and_clicks_the_button() throws Throwable {
		obj.setPffname("ramya");
		 Thread.sleep(2000);
		 obj.setPflname("sharma");
		 Thread.sleep(2000);
		 obj.setPfemail("ramyasharma@gmail.com");
		 Thread.sleep(2000);
		 obj.setPfphone("7895167416");
		 Thread.sleep(2000);
		 obj.setPfcity("Pune");
		 Thread.sleep(2000);
		 obj.setPfstate("Maharashtra");
		 Thread.sleep(2000);
		 obj.setPfpersons("4");
		 Thread.sleep(2000);
		 obj.setPfcardholder("ramya gour");
		 Thread.sleep(2000);
	  obj.setPfdebit("6543 8765 9876 2345");
	  Thread.sleep(2000);
	  obj.setPfCvv("456");
	  Thread.sleep(2000);
	obj.setPfmonth("");
	Thread.sleep(2000);
	obj.setPfbutton();
	   Thread.sleep(2000);
	}

	@When("^user does not enter expiration year and clicks the button$")
	public void user_does_not_enter_expiration_year_and_clicks_the_button() throws Throwable {
		obj.setPffname("ramya");
		 Thread.sleep(2000);
		 obj.setPflname("sharma");
		 Thread.sleep(2000);
		 obj.setPfemail("ramyasharma@gmail.com");
		 Thread.sleep(2000);
		 obj.setPfphone("7895167416");
		 Thread.sleep(2000);
		 obj.setPfcity("Pune");
		 Thread.sleep(2000);
		 obj.setPfstate("Maharashtra");
		 Thread.sleep(2000);
		 obj.setPfpersons("4");
		 Thread.sleep(2000);
		 obj.setPfcardholder("ramya gour");
		 Thread.sleep(2000);
	  obj.setPfdebit("6543 8765 9876 2345");
	  Thread.sleep(2000);
	  obj.setPfCvv("456");
	  Thread.sleep(2000);
	obj.setPfmonth("08");
	Thread.sleep(2000);
	   obj.setPfyear("");
	   Thread.sleep(2000);
	   obj.setPfbutton();
	   Thread.sleep(2000);
	   
	}

	

}
