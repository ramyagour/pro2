package LoginHotelBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageHotel {
	WebDriver driver;

	
	@FindBy(name="userName")
	@CacheLookup
	WebElement pfuname;
	
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement pfpwd;
	
	@FindBy(xpath=".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
	@CacheLookup
	WebElement pfbtn;

	
	//Getter Method
	public WebElement getPfuname() {
		return pfuname;
	}

	public WebElement getPfpwd() {
		return pfpwd;
	}

	public WebElement getPfbtn() {
		return pfbtn;
	}

	
	//Setter Method
	public void setPfuname(String suname) {
		pfuname.sendKeys(suname);
	}

	public void setPfpwd(String spwd) {
		pfpwd.sendKeys(spwd);
	}

	public void setPfbtn() {
		pfbtn.click();
	}

	public PageHotel(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public PageHotel() {
		super();
	}
	

	
	
	
}
