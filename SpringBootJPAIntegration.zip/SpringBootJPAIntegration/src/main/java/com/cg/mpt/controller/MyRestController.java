package com.cg.mpt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mpt.bean.Customer;
import com.cg.mpt.service.ICustomerService;

@RestController
public class MyRestController {
	@Autowired
	ICustomerService service;
	
	/*@RequestMapping(value="/hello",method=RequestMethod.GET,produces="application/json")
	public String hello()
	{
		return "welcome";
	}*/
	
	
	
	/*@RequestMapping(value="/getEmployee",method=RequestMethod.GET)
	public Employee getEmployeeDetails()
	{
		Employee emp=new Employee();
		emp.setEmployeeId(110);
		emp.setFirstName("Ramya");
		emp.setLastName("Gour");
		emp.setMobileno("9627047924");
		emp.setEmail("sharmaramya@gmail.com");
		return emp;
	}*/
	
	
	
	/*@RequestMapping(value="/addCustomer",method=RequestMethod.POST,produces="application/json")
	public Customer addCustomer(@RequestParam("fname")String firstName,@RequestParam("lname")String lastName,@RequestParam("mobno")String mobileNo,@RequestParam("mail")String email)
	{
		Customer customer=new Customer();
		
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setEmail(email);
		customer.setMobileNo(mobileNo);
		customer=service.addCustomer(customer);
		return customer;
	}*/
	
	//add method
	@RequestMapping(value="/addCustomer",consumes="application/json",produces="application/json",method=RequestMethod.POST)
	public Customer addCustomer(@RequestBody Customer customer) {
		
		customer= service.addCustomer(customer);
		return customer;
	}
	
	

	//find method
	@RequestMapping(value="/findCustomer/{custid}",produces="application/json")
	public Customer findCustomer(@PathVariable int custid)
	{
		Customer customer=service.findCustomer(custid);
		return customer;
	}
	
	
	
	//update method
	@RequestMapping(value="/updateCustomer/{custid}",consumes="application/json",produces="application/json")
	public Customer updateCustomer(@RequestBody Customer customer)
	{
		 customer=service.updateCustomer(customer);
		return customer;
	}
	
	
	//remove method
	@RequestMapping(value="/removeCustomer/{custid}",produces="application/json")
	public Customer removeCustomer(@PathVariable int custid)
	{
		Customer customer=service.removeCustomer(custid);
		return customer;
	}
	
	
	
	//get list method
	@RequestMapping(value="getCustomerList",produces="application/json")
	public List<Customer> getCustomerList()
	{
		List<Customer> list=service.getCustomerList();
		return list;
	}
}
