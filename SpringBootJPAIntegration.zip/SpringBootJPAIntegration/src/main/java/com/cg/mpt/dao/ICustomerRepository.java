package com.cg.mpt.dao;
import com.cg.mpt.bean.*;
import java.util.ArrayList;
import java.util.List;

	

public interface ICustomerRepository {

		public Customer addCustomer(Customer customer);
		public Customer findCustomer(int customerid);
		public Customer updateCustomer(Customer customer);
		public List<Customer> getCustomerList();
	public Customer removeCustomer(int custid);
	}


