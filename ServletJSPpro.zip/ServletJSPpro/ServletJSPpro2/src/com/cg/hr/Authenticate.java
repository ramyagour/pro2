package com.cg.hr;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// pick up Query string data(data through GET Method
		// pick up Form Data(data through POST Method)
		// for multiple data  String [] = request.getParameterValues(arg0) , returns array of string
		
		String userName = request.getParameter("user");
		String password = request.getParameter("pass");
		
		RequestDispatcher dispatch=null;
		if(userName.equals("ramya") && (password.equals("qwerty")))
		{
			String fullname = "Ramya Gour";
			// Request Scope
			request.setAttribute("fullname", fullname);
			dispatch=request.getRequestDispatcher("/WEB-INF/pages/Authenticate1.jsp");
		}
		else
		{
			request.setAttribute("message", "Invalid credentials!! Please Try Again");
			dispatch=request.getRequestDispatcher("/WEB-INF/pages/Login1.jsp");
		}
		dispatch.forward(request, response);
		System.out.println("Username is:"+userName);
	}

}
